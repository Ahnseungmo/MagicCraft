Read me File

Thanks for the purchase. I sincerely hope that this set of sprites will be useful for you.

The downloadable file contains everything you need to get started on your game project right away.

Thanks again.